public enum UserState {
    New,
    Active,
    Blocked,
    Banned
}
