public enum OrderStatus {
    New,
    Hold,
    Shipped,
    Delivered,
    Closed
}
